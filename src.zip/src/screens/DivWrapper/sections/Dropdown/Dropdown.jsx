import React from "react";
import { Checkbox } from "../../../../components/Checkbox";
import { Radio } from "../../../../components/Radio";
import { Tab } from "../../../../components/Tab";
import "./style.css";

export const Dropdown = () => {
  return (
    <div className="dropdown">
      <div className="tabs-wrapper">
        <div className="tabs-2">
          <Tab
            className="tab-start-2"
            color="default"
            divClassName="tab-start-3"
            isSelected="off"
            radius="full"
            size="sm"
            text="Audiences"
            variant="default"
          />
          <Tab
            className="tab-3"
            color="default"
            divClassName="design-component-instance-node-2"
            isSelected="on"
            radius="full"
            size="sm"
            text="Demographics"
            variant="default"
          />
        </div>
      </div>

      <div className="checkbox-group">
        <div className="checkboxes">
          <div className="frame-4">
            <div className="text-wrapper-33">Gender</div>
          </div>

          <div className="radio-control">
            <Radio
              color="primary"
              controlClassName="radio-instance"
              isDisabled={false}
              isFocused={false}
              isHovered={false}
              isInvalid={false}
              isSelected={false}
              size="sm"
            />
            <div className="label-wrapper">
              <div className="option-a">All</div>
            </div>
          </div>

          <div className="radio-control">
            <Radio
              color="primary"
              controlClassName="radio-instance"
              isDisabled={false}
              isFocused={false}
              isHovered={false}
              isInvalid={false}
              isSelected={false}
              size="sm"
            />
            <div className="label-wrapper">
              <div className="option-a">female</div>
            </div>
          </div>

          <div className="radio-control">
            <Radio
              className="radio-2"
              color="primary"
              controlClassName="radio-4"
              ellipseClassName="radio-3"
              isDisabled={false}
              isFocused={false}
              isHovered
              isInvalid={false}
              isSelected
              size="sm"
            />
            <div className="label-wrapper">
              <div className="option-a">male</div>
            </div>
          </div>

          <div className="frame-5">
            <div className="text-wrapper-33">Income</div>
          </div>

          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="All"
            tickStyleOverrideClassName="checkbox-3"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="less than $25,000"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="$25,000 to $34,999"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="$35,000 to $49,999"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="$50,000 to $74,999"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="$75,000 to $99,999"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="$100,000 or more"
          />
          <div className="frame-5">
            <div className="text-wrapper-33">Ethnicity</div>
          </div>

          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="All"
            tickStyleOverrideClassName="checkbox-5"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="african american/black"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="asian"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="caucasian"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="hispanic/latino"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="middle eastern"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="native american/alaskan"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="pacific islander"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="other"
          />
          <div className="frame-5">
            <div className="text-wrapper-33">Education</div>
          </div>

          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="All"
            tickStyleOverrideClassName="checkbox-5"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="some high school or less"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="finished high school"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="some college,a.a. degree..."
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="finished college (4-yr degree)"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="post graduate study / degree"
          />
          <div className="frame-5">
            <div className="text-wrapper-33">Region</div>
          </div>

          <div className="checkbox-6">
            <div className="rectangle-wrapper">
              <div className="rectangle-9" />
            </div>

            <div className="text-wrapper-34">All</div>
          </div>

          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="midwest"
            tickStyleOverrideClassName="checkbox-5"
          />
          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="northeast"
            tickStyleOverrideClassName="checkbox-5"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="south"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="west"
          />
          <div className="frame-5">
            <div className="text-wrapper-33">OS</div>
          </div>

          <div className="checkbox-6">
            <div className="rectangle-wrapper">
              <div className="rectangle-9" />
            </div>

            <div className="text-wrapper-34">All</div>
          </div>

          <Checkbox
            checkboxElementClassName="checkbox-2"
            className="checkbox-instance"
            color="primary"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="selected"
            text="apple"
            tickStyleOverrideClassName="checkbox-5"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="android"
          />
          <Checkbox
            checkboxElementClassName="checkbox-4"
            className="checkbox-instance"
            color="default"
            divClassName="design-component-instance-node-2"
            isDisabled="off"
            lineThrough="off"
            radius="none"
            size="sm"
            stateProp="default"
            text="desktop"
          />
        </div>
      </div>
    </div>
  );
};
