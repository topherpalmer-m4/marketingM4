/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { useReducer } from "react";
import { Tick } from "../../icons/Tick";
import "./style.css";

export const Checkbox = ({
  stateProp,
  color,
  size,
  radius,
  isDisabled,
  lineThrough,
  className,
  checkboxElementClassName,
  tickStyleOverrideClassName,
  divClassName,
  text = "Option",
}) => {
  const [state, dispatch] = useReducer(reducer, {
    state: stateProp || "default",

    color: color || "default",

    size: size || "sm",

    radius: radius || "none",

    isDisabled: isDisabled || "off",

    lineThrough: lineThrough || "off",
  });

  return (
    <div
      className={`checkbox ${className}`}
      onMouseLeave={() => {
        dispatch("mouse_leave");
      }}
      onMouseEnter={() => {
        dispatch("mouse_enter");
      }}
      onClick={() => {
        dispatch("click");
      }}
    >
      <div
        className={`checkbox-element ${state.state} ${checkboxElementClassName}`}
      >
        {state.state === "selected" && (
          <Tick className={tickStyleOverrideClassName} />
        )}
      </div>

      <div className={`option ${divClassName}`}>{text}</div>
    </div>
  );
};

function reducer(state, action) {
  if (
    state.color === "default" &&
    state.isDisabled === "off" &&
    state.lineThrough === "off" &&
    state.radius === "none" &&
    state.size === "sm" &&
    state.state === "default"
  ) {
    switch (action) {
      case "mouse_enter":
        return {
          color: "default",

          isDisabled: "off",

          lineThrough: "off",

          radius: "none",

          size: "sm",

          state: "hover",
        };
    }
  }

  if (
    state.color === "default" &&
    state.isDisabled === "off" &&
    state.lineThrough === "off" &&
    state.radius === "none" &&
    state.size === "sm" &&
    state.state === "hover"
  ) {
    switch (action) {
      case "mouse_leave":
        return {
          color: "default",

          isDisabled: "off",

          lineThrough: "off",

          radius: "none",

          size: "sm",

          state: "default",
        };
    }
  }

  if (
    state.color === "primary" &&
    state.isDisabled === "off" &&
    state.lineThrough === "off" &&
    state.radius === "none" &&
    state.size === "sm" &&
    state.state === "selected"
  ) {
    switch (action) {
      case "click":
        return {
          color: "primary",

          isDisabled: "off",

          lineThrough: "off",

          radius: "none",

          size: "sm",

          state: "default",
        };
    }
  }

  return state;
}
