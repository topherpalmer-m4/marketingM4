/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const Radio = ({
  color,
  size,
  isHovered,
  isSelected,
  isFocused,
  isInvalid,
  isDisabled,
  controlClassName,
  className,
  ellipseClassName,
}) => {
  return (
    <div
      className={`radio is-selected-${isSelected} is-hovered-${isHovered} ${className}`}
    >
      <div className={`control ${controlClassName}`}>
        {isHovered && <div className={`ellipse-4 ${ellipseClassName}`} />}
      </div>
    </div>
  );
};
