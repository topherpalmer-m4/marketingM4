/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const Tab = ({
  isSelected,
  radius,
  size,
  variant,
  color,
  className,
  divClassName,
  text = "Text",
}) => {
  return (
    <div className={`tab ${isSelected} ${className}`}>
      <div className={`text-4 ${divClassName}`}>{text}</div>
    </div>
  );
};
