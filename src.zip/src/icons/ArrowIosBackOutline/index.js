export { ArrowIosBackOutline } from "./ArrowIosBackOutline";
